/*
 * Copyright 2011-2020 Branimir Karadzic. All rights reserved.
 * License: https://github.com/bkaradzic/bgfx#license-bsd-2-clause
 */

/*
 *
 * AUTO GENERATED! DO NOT EDIT!
 *
 */

#define BGFX_REV_NUMBER 7238
#define BGFX_REV_SHA1   "8065659e90a2673dd2ac4b12f193604a631833e3"
