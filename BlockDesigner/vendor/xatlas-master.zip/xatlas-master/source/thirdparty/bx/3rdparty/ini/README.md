https://github.com/mattiasgustavsson/libs/
