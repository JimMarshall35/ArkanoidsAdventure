#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4244)
#endif
#define CGLTF_IMPLEMENTATION
#include "cgltf.h"
#ifdef _MSC_VER
#pragma warning(pop)
#endif
